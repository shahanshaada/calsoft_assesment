//colors
export const color_codes={
    $blue001:"rgba(46, 125, 246, 1)"
}

